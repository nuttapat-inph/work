#include<stdio.h>

int score(int no1,int no2)
{
	int sum=0;
	sum = no1+no2;
	return(sum);
	
}
int main()
{
	int no1,no2,sum,amt,j;
	char name[40],lname[40],sub[40];
	j=0;
	printf("Enter your subject: ");
	scanf("%s",&sub);
	printf("Enter student amount: ");
	scanf("%d",&amt);
	
	while(j<amt)
	{
		j++;
		
		printf("*----------------------------------------------------*\n");
		printf("*----------------------------------------------------*\n");
		printf("Enter your full name : ");
		scanf("%s %s",&name,&lname);
		printf("Enter midterm score: ");
		scanf("%d",&no1);
		printf("Enter final score: ");
		scanf("%d",&no2);
		sum = score(no1,no2);
		
		if(sum>=80 && sum<=100)
		{
			printf("Name : %s %s, Grade=A, Excellent!!!!!\n",name,lname);
		}
		else if(sum>=70 && sum<=79)
		{
			printf("Name : %s %s, Grade=B, Very Good!\n",name,lname);
		}
		else if(sum>=60 && sum<=69)
		{
			printf("Name : %s %s, Grade=C, Fair\n",name,lname);
		}
		else if(sum>=50 && sum<=59)
		{
			printf("Name : %s %s, Grade=D, Normal\n",name,lname);
		}
		else if(sum<50)
		{
			printf("Name : %s %s, Grade=F, Not worry....try again !!!\n",name,lname);
		}
		
	}
	printf("*--------------------------------------------------------*\n");
	printf("*--------------------Program terminated--------------------*");
	getch();
	return(0);
}
