/*********************************************************************/
/* AUTRHOR    	:	Nuttapat Inphiwas    	                         */
/* ID		    :	1-60-07-0175-7	                                 */
/* SECTION	    :	1451	                                         */
/* Std. No.     :	22                                           	 */
/* COURSE	    :	CS310 Computer Programming                       */
/* INSTRUCTOR   :	A.Sirinthorn Cheyasak                            */
/* TUTOR	    :	A.Sirinthorn Cheyasak                            */
/* DATE    	    :	October 10 , 2017	                             */
/* LAB NUMBER   :	LAB 7 	                                         */
/* DESCRIPTION  : This program is Used to find the Multiplication    */
/*                table,Comfortable to use.                          */
/*********************************************************************/
#include <stdio.h>
int main()
{
	int num,num1,j ;
	char con ;
	con = 'Y';
	while (toupper(con)!='N')
	{
	printf("Enter start number fo multiplication : ");
	scanf("%d",&num);
	printf("Enter end number fo multiplication : ");
	scanf("%d",&num1);
	
		while (num<=num1)
		{
			j=1 ; 
			while(j<=12)
			{
				
				printf ("%5d",num*j);
				j++;
			}
		printf ("\n");
		num++;
		}
	printf("\nContinute? (Y/N) : ");
	scanf(" %c",&con);
	}
	printf("\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
	printf("\n+-*/+-*/+-*/+-*/-----------------------------+-*/+-*/+-*/+-*/");
	printf("\n+-*/+-*/+-*/+-*/   Thank you for using.      +-*/+-*/+-*/+-*/");
	printf("\n+-*/+-*/+-*/+-*/-----------------------------+-*/+-*/+-*/+-*/");
	printf("\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
	return 0 ;
}
