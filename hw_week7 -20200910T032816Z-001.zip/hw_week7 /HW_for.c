/*********************************************************************/
/* AUTRHOR    	:	Nuttapat Inphiwas    	                         */
/* ID		    :	1-60-07-0175-7	                                 */
/* SECTION	    :	1451	                                         */
/* Std. No.     :	22                                           	 */
/* COURSE	    :	CS310 Computer Programming                       */
/* INSTRUCTOR   :	A.Sirinthorn Cheyasak                            */
/* TUTOR	    :	A.Sirinthorn Cheyasak                            */
/* DATE    	    :	October 10 , 2017	                             */
/* LAB NUMBER   :	LAB 7 	                                         */
/* DESCRIPTION  : This program is Used to find the Multiplication    */
/*                table,Comfortable to use.                          */
/*********************************************************************/
#include <stdio.h>
int main()
{
	int num,num1,i,result;
	
	printf("Enter Start number fo multiplication : ");
	scanf("%d", &num);
	printf("Enter Ehd number fo multiplication : ");
	scanf("%d", &num1);
	
	for(num=1 ; num<=num1 ; num++)
	{
		
		for(i=1;i<=12;i++)
		{
		  
		  
		  printf("%5d",num*i);
		  
		}
		printf("\n");
		
	}
	printf("\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
	printf("\n+-*/+-*/+-*/+-*/-----------------------------+-*/+-*/+-*/+-*/");
	printf("\n+-*/+-*/+-*/+-*/   Thank you for using.      +-*/+-*/+-*/+-*/");
	printf("\n+-*/+-*/+-*/+-*/-----------------------------+-*/+-*/+-*/+-*/");
	printf("\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
	
	return 0;
}
