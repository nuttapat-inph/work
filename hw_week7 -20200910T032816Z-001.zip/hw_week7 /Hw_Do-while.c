/*********************************************************************/
/* AUTRHOR    	:	Nuttapat Inphiwas    	                         */
/* ID		    :	1-60-07-0175-7	                                 */
/* SECTION	    :	1451	                                         */
/* Std. No.     :	22                                           	 */
/* COURSE	    :	CS310 Computer Programming                       */
/* INSTRUCTOR   :	A.Sirinthorn Cheyasak                            */
/* TUTOR	    :	A.Sirinthorn Cheyasak                            */
/* DATE    	    :	October 10 , 2017	                             */
/* LAB NUMBER   :	LAB 7 	                                         */
/* DESCRIPTION  : This program is Used to find the Multiplication    */
/*                table,Comfortable to use.                          */
/*********************************************************************/
#include <stdio.h>
int main()
{
	char con ;
	int num,j,result,num1 ;
	con = 'Y';
	do
	{
	  printf("Enter start number fo multiplication : ");
	  scanf("%d",&num);
	  printf("Enter end number fo multiplication : ");
	  scanf("%d",&num1);
		do
		{
			j=1;
			do
			{
				result = num*j;
				printf ("%5d",result);
				j++;
			}
			while (j<=12);
			printf("\n");
			num ++;
		}
		while (num<=num1);
	    printf("\nContinute? (Y/N) : ");
	    scanf(" %c",&con);
	}
	while (toupper(con)!='N');

	printf("\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
	printf("\n+-*/+-*/+-*/+-*/-----------------------------+-*/+-*/+-*/+-*/");
	printf("\n+-*/+-*/+-*/+-*/   Thank you for using.      +-*/+-*/+-*/+-*/");
	printf("\n+-*/+-*/+-*/+-*/-----------------------------+-*/+-*/+-*/+-*/");
	printf("\n*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
	return 0 ;
}

