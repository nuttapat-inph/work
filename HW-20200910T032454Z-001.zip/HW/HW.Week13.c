/********************************************************************/
/* AURHOR	   :	Nuttapat inphiwas    	                        */
/* ID	       :	1-60-07-0175-7	                                */
/* SECTION	   :	1451	                                        */
/* Std. No.    :	22	                                            */
/* COURSE	   :	CS310 Computer Programming                      */
/* INSTRUCTOR  :	A.Sirinthorn Cheyasak                           */
/* TUTOR   	   :	A.Sirinthorn Cheyasak                           */
/* DATE    	   :	November 21, 2017	                            */
/* LAB NUMBER  :	frist progam	                                */
/* DESCRIPTION :	This program Multipurpose calculator Received   */
/*                    from the keyboard And from                    */
/*                    the information is very comfortable.          */
/********************************************************************/

#include <stdio.h>

void Calcu(num1,num2,oper)
{
	
    if(oper=='+') 
	{
		printf("The answer is %d\n",num1+num2);
	}	
	else if(oper== '-') 
	{
		printf("The answer is %d\n",num1-num2);
	}
	else if(oper== '*') 
	{
		printf("The answer is %d\n",num1*num2);
	}
	else if(oper== '/') 
	{
		printf("The answer is %d\n",num1/num2);
	}
	else if(oper== '%') 
	{
		printf("The answer is %d\n",num1%num2);
	}
	
    else 
	{
		printf("operator not found");
	}
    
}

void ans()	
{
    int num1,num2;
    char oper;

    printf("Enter number 1: ");
    scanf("%d",&num1);
    printf("Enter number 2: ");
    scanf("%d",&num2);
    printf("Enter an operator (+, -, *, /, %): ");
    scanf(" %c",&oper);
    
    Calcu(num1,num2,oper);
    
    
}

void file()
{
    int num1,num2;
    char oper;
    FILE *list,*outlist;
    list = fopen("list.txt","r");
    outlist = fopen("outlist.txt","w");
    printf("List of all transactions \n");
    printf("=============\n");
    

    while(!feof(list))
	{
		fscanf(list,"%d %c %d",&num1,&oper,&num2);
		
    	if(oper=='+') 
		{
			printf("Transaction : num1 = %d,num2 = %d\n",num1,num2);
			printf("The answer is %d\n",num1+num2);
		}	
		else if(oper== '-') 
		{
			printf("Transaction : num1 = %d,num2 = %d\n",num1,num2);;
			printf("The answer is %d\n",num1-num2);
			
		}
		else if(oper== '*') 
		{
			printf("Transaction : num1 = %d,num2 = %d\n",num1,num2);;
			printf("The answer is %d\n",num1*num2);
		}
		else if(oper== '/') 
		{
			printf("Transaction : num1 = %d,num2 = %d\n",num1,num2);
			printf("The answer is %d\n",num1/num2);
		}
		else if(oper== '%') 
		{
			printf("Transaction : num1 = %d,num2 = %d\n",num1,num2);
			printf("The answer is %d\n",num1%num2);
		}
	
    else {printf("operator not found");}
    }

    fclose(list);
    fclose(outlist);
    
    
}

int main()

	{
		
    int menu = 0;

    printf("=====================================================\n");
    printf("+   List of menu                                    +\n");
    printf("+   1.Calculator (get integers from keyboard)       +\n");
    printf("+   2.Calculator (get integers from integer file)   +\n");
    printf("+   3.Exit program                                  +\n");
    printf("=====================================================\n");
    
    printf("Please select menu : ");
    scanf("%d",&menu);

    if(menu == 1)
	{
        ans();  
    }
	else if(menu == 2)
	{
        file();
    } 
	else 
	{
        printf("This program is terminated.");
    }
    
    return 0;
}




